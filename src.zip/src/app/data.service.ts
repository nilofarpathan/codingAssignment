import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { Product } from 'src/app/models/product';


@Injectable({
  providedIn: 'root'
})
export class DataService {

	subject= new Subject();

	private server_url="https://www.mocky.io/v2/5eda4003330000740079ea60";

  constructor( private httpClient: HttpClient) { }

/* fetching Product data from API*/
public getProductList(){
	return this.httpClient.get(this.server_url);
}

/* listening from add to cart */
sendMsg_ToUpdateCartCount(product) {
    this.subject.next(product) //Triggering an event
  }

  getMsg_ToUpdateCartCount() {
    return this.subject.asObservable()
  }


}
