import { Component, OnInit, Input} from '@angular/core';
import { DataService } from '../data.service';
import { Product } from '../models/product';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {


cartTotalAmount:any;
 cartItemsList: Product[] =[];

  constructor(private dataService:DataService) { }

  ngOnInit() {
   this.CountCartOnload();
  	this.dataService.getMsg_ToUpdateCartCount().subscribe((product: Product) => {
      this.CountCart(product)
  })
}
public CountCartOnload(){

 this.cartItemsList =JSON.parse(localStorage.getItem("cartItemsAdded"));
    console.log('Header cart List is loaded', this.cartItemsList);
   if(this.cartItemsList ==null) {
    this.cartItemsList =[];
    console.log('cartItemsList is: ', this.cartItemsList);
   }

    this.cartTotalAmount=0;
    if (this.cartItemsList !=null) {
this.cartItemsList.forEach(item=>{
this.cartTotalAmount += item.quantity;
})
  console.log('cartTotalAmount is: ', this.cartTotalAmount);
  }
}



public CountCart(product: Product){

 this.cartItemsList =JSON.parse(localStorage.getItem("cartItemsAdded"));
    console.log('Header cart List is loaded', this.cartItemsList);
   if(this.cartItemsList ==null) {
    this.cartItemsList =[];
    console.log('cartItemsList is: ', this.cartItemsList);
   }

    this.cartTotalAmount=0;
    if (this.cartItemsList !=null) {
this.cartItemsList.forEach(item=>{
this.cartTotalAmount += item.quantity;
})
  console.log('cartTotalAmount is: ', this.cartTotalAmount);
  }
}

}
