import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DataService } from '../data.service';
import { Product } from '../models/product';



@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

productsList:any = [];
cartItemData: Product[]=[];
countitemSelected:any=[];


  constructor(private dataservice: DataService) {}

  ngOnInit(): void {

this.dataservice.getProductList()
.subscribe((data:any[])=>{
this.productsList=data;
console.log("products: ",this.productsList);
});

  }

  public AddToCart(product:Product){
 this.cartItemData =JSON.parse(localStorage.getItem("cartItemsAdded"));

 if(this.cartItemData ==null) {
    this.cartItemData =[];
    console.log('cartItemData is: ', this.cartItemData);
   }

  	let productExists = false

    for (let i in this.cartItemData) {
      if (this.cartItemData[i].id === product.id) {
        this.cartItemData[i].quantity++;
        productExists = true;
this.countitemSelected=this.cartItemData[i].quantity;
        console.log('If productExists', productExists,   this.countitemSelected);
        break;
      }
    }

  	
  	if (!productExists) {
  	this.cartItemData.push({
        id: product.id,
        name: product.name,
        description: product.description,
        price: product.price,
        quantity: 1,
        image:product.image,
      })
  }
  
  console.log('cartItemData is: ', this.cartItemData);
  localStorage.setItem("cartItemsAdded", JSON.stringify(this.cartItemData));
  this.dataservice.sendMsg_ToUpdateCartCount(this.cartItemData);
}

}
