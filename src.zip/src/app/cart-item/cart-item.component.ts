import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../models/product';
import { DataService } from '../data.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.component.html',
  styleUrls: ['./cart-item.component.scss']
})
export class CartItemComponent implements OnInit {

	// @Input() cartItem:Product[]=[];
	cartTotalAmount:any;
cartItemsList: Product[] =[];
cartTotaQty: any;

  constructor(private dataservice:DataService,  private router: Router) { }

  ngOnInit(){
  	this.cartItemsList =JSON.parse(localStorage.getItem("cartItemsAdded"));

   if(this.cartItemsList ==null) 
   {
    this.cartItemsList =[];
   }
   this.LoadCartTotalAmount();

  }

  // loading cart total amount
  public LoadCartTotalAmount(){
    this.cartTotalAmount=0;
    this.cartTotaQty=0;
    if (this.cartItemsList !=null) {
this.cartItemsList.forEach(item=>{
this.cartTotalAmount += item.quantity *item.price;
this.cartTotaQty +=item.quantity;
})
  }
}
////////////////////////////////////////////////////

public payHere(){
	this.router.navigate(['/productList']);
}
}
