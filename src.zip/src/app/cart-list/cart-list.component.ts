import { Component, OnInit, Input } from '@angular/core';
import { DataService } from '../data.service';
import { Product } from '../models/product';
import { Router } from '@angular/router';



@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.scss']
})
export class CartListComponent implements OnInit {

cartTotalAmount:any;
cartItemsList: Product[] =[];
cartItemData: Product[]=[];

  constructor(private dataservice:DataService, private router: Router) { }

  ngOnInit(){
    
    this.cartItemsList =JSON.parse(localStorage.getItem("cartItemsAdded"));

   if(this.cartItemsList ==null) 
   {
    this.cartItemsList =[];
   }
   this.LoadCartTotalAmount();

  }

// loading cart total amount
  public LoadCartTotalAmount(){
    this.cartTotalAmount=0;
    if (this.cartItemsList !=null) {
this.cartItemsList.forEach(item=>{
this.cartTotalAmount += item.quantity *item.price;
})
  }
}
////////////////////////////////////////////////////

// deleting cart item one by one
   public DeleteItem(cartItem: Product){
  
   this.cartItemsList =JSON.parse(localStorage.getItem("cartItemsAdded"));
   
   for (var i = 0; i < this.cartItemsList.length; i++) {

      var itemSelected = this.cartItemsList[i];
       if(itemSelected.id === cartItem.id){
        this.cartItemsList[i].quantity --;
        if(this.cartItemsList[i].quantity === 0){
          this.cartItemsList.splice(i, 1);
        }
         
       }     
    }
          localStorage.setItem("cartItemsAdded", JSON.stringify(this.cartItemsList));
          this.cartItemsList =JSON.parse(localStorage.getItem("cartItemsAdded"));
          this.dataservice.sendMsg_ToUpdateCartCount(this.cartItemsList);
          this.LoadCartTotalAmount();
}
////////////////////////////////////////////////////////

//add to cart
 public AddToCart(product:Product){
 this.cartItemData =JSON.parse(localStorage.getItem("cartItemsAdded"));
    let productExists = false

//checking if item already exists then incrementing quantity only
    for (let i in this.cartItemData) {
      if (this.cartItemData[i].id === product.id) {
        this.cartItemData[i].quantity++;
        productExists = true;
        break;
      }
    }

//adding item if not exists    
    if (!productExists) {
    this.cartItemData.push({
        id: product.id,
        name: product.name,
        description: product.description,
        price: product.price,
        quantity: 1,
        image:product.image,
      })
  }
      
      localStorage.setItem("cartItemsAdded", JSON.stringify(this.cartItemData));
      this.dataservice.sendMsg_ToUpdateCartCount(this.cartItemData);
      this.ngOnInit();

}
//////////////////////////////////////////////////////////////////

//empty cart
public emptyCart(){
  localStorage.removeItem('cartItemsAdded');
  this.dataservice.sendMsg_ToUpdateCartCount(this.cartItemData);
  this.router.navigate(['/productList']);
  this.ngOnInit();
  
  
}


}
